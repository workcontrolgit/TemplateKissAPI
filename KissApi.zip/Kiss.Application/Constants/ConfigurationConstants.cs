﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Constants
{
    public static class ConfigurationConstants
    {
        public const string ConnectionString = "ConnectionStrings:DefaultConnection";
    }
}
