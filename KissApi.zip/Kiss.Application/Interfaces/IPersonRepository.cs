﻿using $ext_projectname$.Domain.Entities;

namespace $safeprojectname$.Interfaces
{
    public interface IPersonRepository : IGenericRepository<Person>
    {
    }
}
