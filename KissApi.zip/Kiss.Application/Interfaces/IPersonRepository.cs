﻿using $ext_projectname$.Core.Entities;

namespace $safeprojectname$.Interfaces
{
    public interface IPersonRepository : IGenericRepository<Person>
    {
    }
}
