﻿using $ext_projectname$.Domain.Entities;

namespace $safeprojectname$.Interfaces
{
    public interface IProductRepository : IGenericRepository<Product>
    {
    }
}
