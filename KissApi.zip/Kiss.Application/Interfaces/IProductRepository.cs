﻿using $ext_projectname$.Core.Entities;

namespace $safeprojectname$.Interfaces
{
    public interface IProductRepository : IGenericRepository<Product>
    {
    }
}
